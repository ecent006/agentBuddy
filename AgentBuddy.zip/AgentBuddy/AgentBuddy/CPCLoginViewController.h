//
//  CPCViewController.h
//  AgentBuddy
//
//  Created by Lion User on 10/11/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class  CPCAppDelegate;

@interface CPCLoginViewController : UIViewController <UITextFieldDelegate>
{
    CPCAppDelegate *appDelegate;
}

@end
