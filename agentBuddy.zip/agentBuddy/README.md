agentBuddy
==========

Open-Source, objective-C app to create auto claims, edit, and view with an  agent's account