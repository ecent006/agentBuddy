//
//  CPCClaimsInfo.m
//  AgentBuddy
//
//  Created by Lion User on 11/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CPCClaimsInfo.h"

@implementation CPCClaimsInfo

@end
